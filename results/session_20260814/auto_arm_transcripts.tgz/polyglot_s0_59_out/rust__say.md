
========== User Instruction ==========
I have uploaded a code repository in the directory /testbed/. Help solve the following problem.

<problem_description>
# Instructions append

## Rust Specific Exercise Notes

This is slightly changed in the Rust version, compared to other
language versions of this exercise.  Instead of requiring you to return
errors for out of range, we are using Rust's strong type system to limit
input.  It is much easier to make a function deal with all valid inputs,
rather than requiring the user of your module to handle errors.

There is a -1 version of a test case, but it is commented out.
If your function is implemented properly, the -1 test case should not compile.

Adding 'and' into number text has not been implemented in test cases.

### Extension

Add capability of converting up to the max value for u64: `18_446_744_073_709_551_615`.

For hints at the output this should have, look at the last test case.


# Instructions

Given a number from 0 to 999,999,999,999, spell out that number in English.

## Step 1

Handle the basic case of 0 through 99.

If the input to the program is `22`, then the output should be `'twenty-two'`.

Your program should complain loudly if given a number outside the blessed range.

Some good test cases for this program are:

- 0
- 14
- 50
- 98
- -1
- 100

### Extension

If you're on a Mac, shell out to Mac OS X's `say` program to talk out loud.
If you're on Linux or Windows, eSpeakNG may be available with the command `espeak`.

## Step 2

Implement breaking a number up into chunks of thousands.

So `1234567890` should yield a list like 1, 234, 567, and 890, while the far simpler `1000` should yield just 1 and 0.

## Step 3

Now handle inserting the appropriate scale word between those chunks.

So `1234567890` should yield `'1 billion 234 million 567 thousand 890'`

The program must also report any values that are out of range.
It's fine to stop at "trillion".

## Step 4

Put it all together to get nothing but plain English.

`12345` should give `twelve thousand three hundred forty-five`.

The program must also report any values that are out of range.



</problem_description>

Your task is to make changes to the files in the /testbed/ directory to address the <problem_description>. I have already taken care of the required dependencies.


Please analyze the problem description carefully. Then make edits to the code files to complete the instruction.
Tool Response: ChatCompletion(id='chatcmpl-a8d647d8ae36e9cd', choices=[Choice(finish_reason='stop', index=0, logprobs=None, message=ChatCompletionMessage(content='Let\'s break down the problem and plan the steps to solve it. We\'ll tackle each step systematically and ensure that our solution covers all the requirements mentioned in the problem description.\n\n### Step-by-Step Plan\n\n1. **Handle the basic case of 0 through 99**: This involves mapping numbers to their corresponding English words.\n2. **Break a number up into chunks of thousands**: This requires dividing the number into parts (e.g., millions, thousands).\n3. **Insert the appropriate scale word between those chunks**: This involves adding words like "million," "billion," etc., based on the size of the number.\n4. **Combine everything to get plain English**: This involves putting all the parts together into a coherent sentence.\n\n### Implementation Steps\n\n#### Step 1: Handle the basic case of 0 through 99\n\nWe\'ll create a helper function to map numbers to their English words.\n\n```rust\nfn number_to_words(num: u32) -> String {\n    let belowTwenty = vec![\n        "", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",\n        "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen",\n        "seventeen", "eighteen", "nineteen",\n    ];\n    let tens = vec![\n        "", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety",\n    ];\n\n    match num {\n        0..=19 => belowTwenty[num as usize].to_string(),\n        20..=99 => {\n            let ten = num / 10;\n            let rest = num % 10;\n            format!("{}{}", tens[ten as usize], if rest > 0 { format!(" {}", belowTwenty[rest as usize]) } else { "".to_string() })\n        }\n        _ => panic!("Number out of range"),\n    }\n}\n```\n\n#### Step 2: Break a number up into chunks of thousands\n\nWe\'ll create a function to split the number into chunks of thousands.\n\n```rust\nfn split_into_chunks(mut num: u64) -> Vec<u32> {\n    let mut chunks = Vec::new();\n    while num > 0 {\n        chunks.push((num % 1000) as u32);\n        num /= 1000;\n    }\n    chunks.reverse();\n    chunks\n}\n```\n\n#### Step 3: Insert the appropriate scale word between those chunks\n\nWe\'ll create a function to add scale words based on the chunk index.\n\n```rust\nfn add_scale_word(chunk_index: usize) -> Option<&str> {\n    match chunk_index {\n        0 => None,\n        1 => Some("thousand"),\n        2 => Some("million"),\n        3 => Some("billion"),\n        _ => None,\n    }\n}\n```\n\n#### Step 4: Combine everything to get plain English\n\nFinally, we\'ll combine all the parts into a coherent sentence.\n\n```rust\npub fn number_to_words_full(num: u64) -> String {\n    if num == 0 {\n        return "zero".to_string();\n    }\n\n    let chunks = split_into_chunks(num);\n    let mut result = String::new();\n\n    for (i, &chunk) in chunks.iter().enumerate() {\n        if chunk != 0 {\n            if !result.is_empty() {\n                result.push(\' \');\n            }\n            result.push_str(&number_to_words(chunk));\n            if let Some(scale_word) = add_scale_word(i) {\n                result.push(\' \');\n                result.push_str(scale_word);\n            }\n        }\n    }\n\n    result\n}\n```\n\n### Putting It All Together\n\nHere\'s the complete implementation in a single file:\n\n```rust\nfn number_to_words(num: u32) -> String {\n    let belowTwenty = vec![\n        "", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",\n        "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen",\n        "seventeen", "eighteen", "nineteen",\n    ];\n    let tens = vec![\n        "", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety",\n    ];\n\n    match num {\n        0..=19 => belowTwenty[num as usize].to_string(),\n        20..=99 => {\n            let ten = num / 10;\n            let rest = num % 10;\n            format!("{}{}", tens[ten as usize], if rest > 0 { format!(" {}", belowTwenty[rest as usize]) } else { "".to_string() })\n        }\n        _ => panic!("Number out of range"),\n    }\n}\n\nfn split_into_chunks(mut num: u64) -> Vec<u32> {\n    let mut chunks = Vec::new();\n    while num > 0 {\n        chunks.push((num % 1000) as u32);\n        num /= 1000;\n    }\n    chunks.reverse();\n    chunks\n}\n\nfn add_scale_word(chunk_index: usize) -> Option<&str> {\n    match chunk_index {\n        0 => None,\n        1 => Some("thousand"),\n        2 => Some("million"),\n        3 => Some("billion"),\n        _ => None,\n    }\n}\n\npub fn number_to_words_full(num: u64) -> String {\n    if num == 0 {\n        return "zero".to_string();\n    }\n\n    let chunks = split_into_chunks(num);\n    let mut result = String::new();\n\n    for (i, &chunk) in chunks.iter().enumerate() {\n        if chunk != 0 {\n            if !result.is_empty() {\n                result.push(\' \');\n            }\n            result.push_str(&number_to_words(chunk));\n            if let Some(scale_word) = add_scale_word(i) {\n                result.push(\' \');\n                result.push_str(scale_word);\n            }\n        }\n    }\n\n    result\n}\n```\n\n### Testing\n\nTo test the implementation, you can use the following test cases:\n\n```rust\nfn main() {\n    assert_eq!(number_to_words_full(0), "zero");\n    assert_eq!(number_to_words_full(14), "fourteen");\n    assert_eq!(number_to_words_full(50), "fifty");\n    assert_eq!(number_to_words_full(98), "ninety-eight");\n    assert_eq!(number_to_words_full(1000), "one thousand");\n    assert_eq!(number_to_words_full(1234567890), "one billion two hundred thirty-four million five hundred sixty-seven thousand eight hundred ninety");\n    println!("All tests passed!");\n}\n```\n\n### Conclusion\n\nThis implementation should cover all the requirements mentioned in the problem description. It handles numbers from 0 to 99, breaks them into chunks of thousands, adds the appropriate scale words, and combines everything into a coherent sentence.', refusal=None, role='assistant', annotations=None, audio=None, function_call=None, tool_calls=None, reasoning=None), stop_reason=None, token_ids=None, routed_experts=None)], created=1786135560, model='Qwen/Qwen2.5-Coder-7B-Instruct', object='chat.completion', moderation=None, service_tier=None, system_fingerprint='vllm-0.26.0-d384e2c5', usage=CompletionUsage(completion_tokens=1512, prompt_tokens=1283, total_tokens=2795, completion_tokens_details=None, prompt_tokens_details=None), prompt_logprobs=None, prompt_token_ids=None, prompt_text=None, kv_transfer_params=None, ec_transfer_params=None, metrics=None)
