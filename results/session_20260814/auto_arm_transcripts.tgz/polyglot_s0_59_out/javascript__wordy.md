
========== User Instruction ==========
I have uploaded a code repository in the directory /testbed/. Help solve the following problem.

<problem_description>
# Instructions

Parse and evaluate simple math word problems returning the answer as an integer.

## Iteration 0 — Numbers

Problems with no operations simply evaluate to the number given.

> What is 5?

Evaluates to 5.

## Iteration 1 — Addition

Add two numbers together.

> What is 5 plus 13?

Evaluates to 18.

Handle large numbers and negative numbers.

## Iteration 2 — Subtraction, Multiplication and Division

Now, perform the other three operations.

> What is 7 minus 5?

2

> What is 6 multiplied by 4?

24

> What is 25 divided by 5?

5

## Iteration 3 — Multiple Operations

Handle a set of operations, in sequence.

Since these are verbal word problems, evaluate the expression from left-to-right, _ignoring the typical order of operations._

> What is 5 plus 13 plus 6?

24

> What is 3 plus 2 multiplied by 3?

15 (i.e. not 9)

## Iteration 4 — Errors

The parser should reject:

- Unsupported operations ("What is 52 cubed?")
- Non-math questions ("Who is the President of the United States")
- Word problems with invalid syntax ("What is 1 plus plus 2?")



</problem_description>

Your task is to make changes to the files in the /testbed/ directory to address the <problem_description>. I have already taken care of the required dependencies.


Please analyze the problem description carefully. Then make edits to the code files to complete the instruction.
Tool Response: ChatCompletion(id='chatcmpl-b36f56e2ebe9ec7a', choices=[Choice(finish_reason='stop', index=0, logprobs=None, message=ChatCompletionMessage(content='Let\'s break down the problem and create a solution step-by-step. We\'ll use Python to implement the functionality described in the problem statement. Here’s how we can approach this:\n\n1. **Read and Parse Input**: Extract the question from the input.\n2. **Identify and Handle Different Operations**: Perform addition, subtraction, multiplication, and division based on the words used.\n3. **Handle Multiple Operations**: Evaluate expressions from left to right.\n4. **Error Handling**: Reject unsupported operations, non-math questions, and invalid syntax.\n\n### Step 1: Create a Main Script\n\nWe\'ll create a main script named `math_solver.py` that reads the input, processes it, and outputs the result.\n\n```python\nimport re\n\ndef parse_and_evaluate(question):\n    # Remove any leading/trailing whitespace and convert to lowercase\n    question = question.strip().lower()\n    \n    # Check for unsupported operations\n    if "cubed" in question or "squared" in question:\n        raise ValueError("Unsupported operation.")\n    \n    # Check for non-math questions\n    if not re.match(r\'what is \\d+\', question):\n        raise ValueError("Non-math question.")\n    \n    # Split the question into tokens\n    tokens = question.split()\n    \n    # Initialize the result with the first number\n    result = int(tokens[2])\n    \n    # Process the rest of the tokens\n    i = 3\n    while i < len(tokens):\n        operator = tokens[i]\n        num = int(tokens[i + 1])\n        \n        if operator == "plus":\n            result += num\n        elif operator == "minus":\n            result -= num\n        elif operator == "multiplied by":\n            result *= num\n        elif operator == "divided by":\n            result //= num\n        else:\n            raise ValueError("Invalid syntax.")\n        \n        i += 2\n    \n    return result\n\nif __name__ == "__main__":\n    import sys\n    if len(sys.argv) != 2:\n        print("Usage: python math_solver.py \'<question>\'")\n        sys.exit(1)\n    \n    question = sys.argv[1]\n    try:\n        result = parse_and_evaluate(question)\n        print(result)\n    except ValueError as e:\n        print(e)\n```\n\n### Step 2: Test the Script\n\nTo ensure our script works correctly, let\'s test it with various inputs:\n\n```sh\npython math_solver.py "What is 5?"\n# Expected output: 5\n\npython math_solver.py "What is 5 plus 13?"\n# Expected output: 18\n\npython math_solver.py "What is 7 minus 5?"\n# Expected output: 2\n\npython math_solver.py "What is 6 multiplied by 4?"\n# Expected output: 24\n\npython math_solver.py "What is 25 divided by 5?"\n# Expected output: 5\n\npython math_solver.py "What is 5 plus 13 plus 6?"\n# Expected output: 24\n\npython math_solver.py "What is 3 plus 2 multiplied by 3?"\n# Expected output: 15\n\npython math_solver.py "What is 52 cubed?"\n# Expected output: Unsupported operation.\n\npython math_solver.py "Who is the President of the United States"\n# Expected output: Non-math question.\n\npython math_solver.py "What is 1 plus plus 2?"\n# Expected output: Invalid syntax.\n```\n\n### Step 3: Update the Directory Structure\n\nPlace the `math_solver.py` script in the `/testbed/` directory.\n\n### Final Steps\n\nEnsure the script has execute permissions:\n\n```sh\nchmod +x /testbed/math_solver.py\n```\n\nYou can now run the script using the following command:\n\n```sh\npython /testbed/math_solver.py "<your_question>"\n```\n\nThis should handle all the requirements mentioned in the problem description.', refusal=None, role='assistant', annotations=None, audio=None, function_call=None, tool_calls=None, reasoning=None), stop_reason=None, token_ids=None, routed_experts=None)], created=1786131749, model='Qwen/Qwen2.5-Coder-7B-Instruct', object='chat.completion', moderation=None, service_tier=None, system_fingerprint='vllm-0.26.0-d384e2c5', usage=CompletionUsage(completion_tokens=807, prompt_tokens=1015, total_tokens=1822, completion_tokens_details=None, prompt_tokens_details=None), prompt_logprobs=None, prompt_token_ids=None, prompt_text=None, kv_transfer_params=None, ec_transfer_params=None, metrics=None)
