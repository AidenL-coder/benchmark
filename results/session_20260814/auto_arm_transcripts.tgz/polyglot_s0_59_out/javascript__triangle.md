
========== User Instruction ==========
I have uploaded a code repository in the directory /testbed/. Help solve the following problem.

<problem_description>
# Instructions

Determine if a triangle is equilateral, isosceles, or scalene.

An _equilateral_ triangle has all three sides the same length.

An _isosceles_ triangle has at least two sides the same length.
(It is sometimes specified as having exactly two sides the same length, but for the purposes of this exercise we'll say at least two.)

A _scalene_ triangle has all sides of different lengths.

## Note

For a shape to be a triangle at all, all sides have to be of length > 0, and the sum of the lengths of any two sides must be greater than or equal to the length of the third side.

In equations:

Let `a`, `b`, and `c` be sides of the triangle.
Then all three of the following expressions must be true:

```text
a + b ≥ c
b + c ≥ a
a + c ≥ b
```

See [Triangle Inequality][triangle-inequality]

[triangle-inequality]: https://en.wikipedia.org/wiki/Triangle_inequality



</problem_description>

Your task is to make changes to the files in the /testbed/ directory to address the <problem_description>. I have already taken care of the required dependencies.


Please analyze the problem description carefully. Then make edits to the code files to complete the instruction.
Tool Response: ChatCompletion(id='chatcmpl-9d63b0eead4d4ccd', choices=[Choice(finish_reason='stop', index=0, logprobs=None, message=ChatCompletionMessage(content='To determine if a triangle is equilateral, isosceles, or scalene, we need to implement logic that checks the properties of the triangle based on its side lengths. Here\'s how we can approach this:\n\n1. **Check if the sides form a valid triangle**: Ensure that all sides are greater than 0 and satisfy the triangle inequality.\n2. **Classify the triangle**:\n   - Equilateral: All three sides are equal.\n   - Isosceles: At least two sides are equal.\n   - Scalene: All three sides are different.\n\nWe will write a Python script to perform these checks. Let\'s create a new file named `triangle_classifier.py` in the `/testbed/` directory.\n\n### Step-by-Step Implementation\n\n1. **Create the `triangle_classifier.py` file**:\n   ```python\n   def classify_triangle(a, b, c):\n       # Check if the sides form a valid triangle\n       if a <= 0 or b <= 0 or c <= 0:\n           return "Invalid Triangle"\n       if a + b < c or b + c < a or a + c < b:\n           return "Invalid Triangle"\n\n       # Classify the triangle\n       if a == b == c:\n           return "Equilateral Triangle"\n       elif a == b or b == c or a == c:\n           return "Isosceles Triangle"\n       else:\n           return "Scalene Triangle"\n\n   if __name__ == "__main__":\n       # Example usage\n       print(classify_triangle(3, 4, 5))  # Output: Scalene Triangle\n       print(classify_triangle(5, 5, 5))  # Output: Equilateral Triangle\n       print(classify_triangle(2, 2, 3))  # Output: Isosceles Triangle\n       print(classify_triangle(0, 2, 3))  # Output: Invalid Triangle\n   ```\n\n2. **Save the file** in the `/testbed/` directory.\n\n### Explanation\n\n- **Function `classify_triangle(a, b, c)`**:\n  - It first checks if the sides form a valid triangle using the triangle inequality theorem.\n  - If the sides are valid, it then classifies the triangle as equilateral, isosceles, or scalene based on the equality of the sides.\n\n- **Example Usage**:\n  - The script includes an example usage at the bottom to demonstrate how the function works.\n\n### Next Steps\n\n- You can now test the script by running it from your terminal or any Python environment.\n- To test, navigate to the `/testbed/` directory and run:\n  ```sh\n  python triangle_classifier.py\n  ```\n\nThis should output the classification of the triangles based on the given side lengths.\n\nIf you need further assistance or additional functionality, feel free to ask!', refusal=None, role='assistant', annotations=None, audio=None, function_call=None, tool_calls=None, reasoning=None), stop_reason=None, token_ids=None, routed_experts=None)], created=1786130657, model='Qwen/Qwen2.5-Coder-7B-Instruct', object='chat.completion', moderation=None, service_tier=None, system_fingerprint='vllm-0.26.0-d384e2c5', usage=CompletionUsage(completion_tokens=594, prompt_tokens=951, total_tokens=1545, completion_tokens_details=None, prompt_tokens_details=None), prompt_logprobs=None, prompt_token_ids=None, prompt_text=None, kv_transfer_params=None, ec_transfer_params=None, metrics=None)
