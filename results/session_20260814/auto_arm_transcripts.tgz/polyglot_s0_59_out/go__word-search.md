
========== User Instruction ==========
I have uploaded a code repository in the directory /testbed/. Help solve the following problem.

<problem_description>
# Instructions

In word search puzzles you get a square of letters and have to find specific words in them.

For example:

```text
jefblpepre
camdcimgtc
oivokprjsm
pbwasqroua
rixilelhrs
wolcqlirpc
screeaumgr
alxhpburyi
jalaycalmp
clojurermt
```

There are several programming languages hidden in the above square.

Words can be hidden in all kinds of directions: left-to-right, right-to-left, vertical and diagonal.

Given a puzzle and a list of words return the location of the first and last letter of each word.



</problem_description>

Your task is to make changes to the files in the /testbed/ directory to address the <problem_description>. I have already taken care of the required dependencies.


Please analyze the problem description carefully. Then make edits to the code files to complete the instruction.
Tool Response: ChatCompletion(id='chatcmpl-b062558e463ae0ef', choices=[Choice(finish_reason='stop', index=0, logprobs=None, message=ChatCompletionMessage(content='Let\'s approach this step-by-step:\n\n1. **Understand the Problem**: We need to create a program that can find words in a given word search puzzle in various directions (left-to-right, right-to-left, vertical, and diagonal). For each word found, we need to return the starting and ending positions.\n\n2. **Plan the Solution**:\n   - Create a function to check for words horizontally.\n   - Create a function to check for words vertically.\n   - Create a function to check for words diagonally from top-left to bottom-right.\n   - Create a function to check for words diagonally from top-right to bottom-left.\n   - Combine these functions to search through the entire puzzle.\n\n3. **Implement the Solution**:\n   - We\'ll use nested loops to iterate through each cell in the puzzle.\n   - For each cell, we\'ll check all possible directions for the presence of the word.\n\n4. **Create the Code Files**:\n   - Let\'s assume we have a file named `word_search.py` where we will implement our solution.\n\nHere is the implementation:\n\n```python\ndef find_word(puzzle, word):\n    rows = len(puzzle)\n    cols = len(puzzle[0])\n\n    # Check horizontal\n    for row in range(rows):\n        for col in range(cols - len(word) + 1):\n            if \'\'.join(puzzle[row][col:col+len(word)]) == word:\n                return (row, col), (row, col + len(word) - 1)\n\n    # Check vertical\n    for col in range(cols):\n        for row in range(rows - len(word) + 1):\n            if \'\'.join([puzzle[r][col] for r in range(row, row + len(word))]) == word:\n                return (row, col), (row + len(word) - 1, col)\n\n    # Check diagonal (top-left to bottom-right)\n    for row in range(rows - len(word) + 1):\n        for col in range(cols - len(word) + 1):\n            if \'\'.join([puzzle[row+i][col+i] for i in range(len(word))]) == word:\n                return (row, col), (row + len(word) - 1, col + len(word) - 1)\n\n    # Check diagonal (top-right to bottom-left)\n    for row in range(rows - len(word) + 1):\n        for col in range(len(word) - 1, cols):\n            if \'\'.join([puzzle[row+i][col-i] for i in range(len(word))]) == word:\n                return (row, col), (row + len(word) - 1, col - len(word) + 1)\n\n    return None\n\ndef find_all_words(puzzle, words):\n    results = {}\n    for word in words:\n        result = find_word(puzzle, word)\n        if result:\n            results[word] = result\n    return results\n\n# Example usage\nif __name__ == "__main__":\n    puzzle = [\n        [\'j\', \'e\', \'f\', \'b\', \'l\', \'p\', \'e\', \'r\', \'p\', \'e\'],\n        [\'c\', \'a\', \'m\', \'d\', \'c\', \'i\', \'m\', \'g\', \'t\', \'c\'],\n        [\'o\', \'i\', \'v\', \'o\', \'k\', \'p\', \'r\', \'j\', \'s\', \'m\'],\n        [\'p\', \'b\', \'w\', \'a\', \'s\', \'q\', \'r\', \'o\', \'u\', \'a\'],\n        [\'r\', \'i\', \'x\', \'i\', \'l\', \'e\', \'l\', \'h\', \'r\', \'s\'],\n        [\'w\', \'o\', \'l\', \'c\', \'q\', \'l\', \'i\', \'r\', \'p\', \'c\'],\n        [\'s\', \'c\', \'r\', \'e\', \'e\', \'a\', \'u\', \'m\', \'g\', \'r\'],\n        [\'a\', \'l\', \'x\', \'h\', \'p\', \'b\', \'u\', \'r\', \'y\', \'i\'],\n        [\'j\', \'a\', \'l\', \'a\', \'y\', \'c\', \'a\', \'l\', \'m\', \'p\'],\n        [\'c\', \'l\', \'o\', \'j\', \'u\', \'r\', \'e\', \'r\', \'m\', \'t\']\n    ]\n    words = ["java", "python", "javascript"]\n    print(find_all_words(puzzle, words))\n```\n\n### Explanation:\n- `find_word`: This function checks for a single word in all four directions.\n- `find_all_words`: This function iterates through a list of words and uses `find_word` to locate each word in the puzzle.\n- The example usage at the end demonstrates how to use these functions with a sample puzzle and a list of words.\n\n### Steps to Implement:\n1. Create a new file named `word_search.py`.\n2. Copy the above code into `word_search.py`.\n3. Adjust the `puzzle` variable with your actual puzzle data.\n4. Run the script to see the output.\n\nThis should give you a good starting point to solve the word search puzzle problem.', refusal=None, role='assistant', annotations=None, audio=None, function_call=None, tool_calls=None, reasoning=None), stop_reason=None, token_ids=None, routed_experts=None)], created=1786132699, model='Qwen/Qwen2.5-Coder-7B-Instruct', object='chat.completion', moderation=None, service_tier=None, system_fingerprint='vllm-0.26.0-d384e2c5', usage=CompletionUsage(completion_tokens=1102, prompt_tokens=872, total_tokens=1974, completion_tokens_details=None, prompt_tokens_details=None), prompt_logprobs=None, prompt_token_ids=None, prompt_text=None, kv_transfer_params=None, ec_transfer_params=None, metrics=None)
