
========== User Instruction ==========
I have uploaded a code repository in the directory /testbed/. Help solve the following problem.

<problem_description>
# Instructions

Implement a RESTful API for tracking IOUs.

Four roommates have a habit of borrowing money from each other frequently, and have trouble remembering who owes whom, and how much.

Your task is to implement a simple [RESTful API][restful-wikipedia] that receives [IOU][iou]s as POST requests, and can deliver specified summary information via GET requests.

## API Specification

### User object

```json
{
  "name": "Adam",
  "owes": {
    "Bob": 12.0,
    "Chuck": 4.0,
    "Dan": 9.5
  },
  "owed_by": {
    "Bob": 6.5,
    "Dan": 2.75
  },
  "balance": "<(total owed by other users) - (total owed to other users)>"
}
```

### Methods

| Description              | HTTP Method | URL    | Payload Format                                                            | Response w/o Payload                   | Response w/ Payload                                                             |
| ------------------------ | ----------- | ------ | ------------------------------------------------------------------------- | -------------------------------------- | ------------------------------------------------------------------------------- |
| List of user information | GET         | /users | `{"users":["Adam","Bob"]}`                                                | `{"users":<List of all User objects>}` | `{"users":<List of User objects for <users> (sorted by name)}`                  |
| Create user              | POST        | /add   | `{"user":<name of new user (unique)>}`                                    | N/A                                    | `<User object for new user>`                                                    |
| Create IOU               | POST        | /iou   | `{"lender":<name of lender>,"borrower":<name of borrower>,"amount":5.25}` | N/A                                    | `{"users":<updated User objects for <lender> and <borrower> (sorted by name)>}` |

## Other Resources

- [REST API Tutorial][restfulapi]
- Example RESTful APIs
  - [GitHub][github-rest]
  - [Reddit][reddit-rest]

[restful-wikipedia]: https://en.wikipedia.org/wiki/Representational_state_transfer
[iou]: https://en.wikipedia.org/wiki/IOU
[github-rest]: https://developer.github.com/v3/
[reddit-rest]: https://web.archive.org/web/20231202231149/https://www.reddit.com/dev/api/
[restfulapi]: https://restfulapi.net/



</problem_description>

Your task is to make changes to the files in the /testbed/ directory to address the <problem_description>. I have already taken care of the required dependencies.


Please analyze the problem description carefully. Then make edits to the code files to complete the instruction.
Tool Response: ChatCompletion(id='chatcmpl-9abd023670b7eaf7', choices=[Choice(finish_reason='stop', index=0, logprobs=None, message=ChatCompletionMessage(content='To implement the RESTful API for tracking IOUs, we need to create the necessary endpoints and handle the logic for creating users and IOUs. We\'ll use Python\'s Flask framework to build the API.\n\nHere\'s a step-by-step approach:\n\n1. **Set up the Flask application**.\n2. **Create routes for listing users, adding users, and creating IOUs**.\n3. **Handle the logic for updating the user balances based on IOUs**.\n\nLet\'s start by setting up the Flask application and defining the initial data structure for the users.\n\n### Step 1: Set up the Flask application\n\nFirst, create a new file named `app.py` in the `/testbed/` directory.\n\n```python\nfrom flask import Flask, request, jsonify\n\napp = Flask(__name__)\n\n# Initialize the user database\nusers_db = {}\n\n@app.route(\'/users\', methods=[\'GET\'])\ndef get_users():\n    users = sorted(users_db.keys())\n    return jsonify({\'users\': users})\n\n@app.route(\'/add\', methods=[\'POST\'])\ndef add_user():\n    data = request.get_json()\n    user_name = data[\'user\']\n    \n    if user_name in users_db:\n        return jsonify(f\'User {user_name} already exists\'), 400\n    \n    users_db[user_name] = {\n        \'owes\': {},\n        \'owed_by\': {},\n        \'balance\': 0.0\n    }\n    \n    return jsonify(users_db[user_name])\n\n@app.route(\'/iou\', methods=[\'POST\'])\ndef create_iou():\n    data = request.get_json()\n    lender = data[\'lender\']\n    borrower = data[\'borrower\']\n    amount = data[\'amount\']\n    \n    if lender not in users_db or borrower not in users_db:\n        return jsonify(\'Lender or Borrower not found\'), 400\n    \n    # Update lender\'s balance\n    if borrower in users_db[lender][\'owes\']:\n        users_db[lender][\'owes\'][borrower] += amount\n    else:\n        users_db[lender][\'owes\'][borrower] = amount\n    \n    # Update borrower\'s balance\n    if lender in users_db[borrower][\'owed_by\']:\n        users_db[borrower][\'owed_by\'][lender] += amount\n    else:\n        users_db[borrower][\'owed_by\'][lender] = amount\n    \n    # Calculate total balance for each user\n    users_db[lender][\'balance\'] = sum(users_db[lender][\'owes\'].values()) - sum(users_db[lender][\'owed_by\'].values())\n    users_db[borrower][\'balance\'] = sum(users_db[borrower][\'owes\'].values()) - sum(users_db[borrower][\'owed_by\'].values())\n    \n    return jsonify({\'users\': [users_db[lender], users_db[borrower]]})\n\nif __name__ == \'__main__\':\n    app.run(debug=True)\n```\n\n### Step 2: Run the Flask application\n\nNavigate to the `/testbed/` directory in your terminal and run the Flask application:\n\n```sh\npython app.py\n```\n\n### Step 3: Test the API\n\nYou can test the API using tools like Postman or curl.\n\n#### List Users\n\n```sh\ncurl http://127.0.0.1:5000/users\n```\n\n#### Add User\n\n```sh\ncurl -X POST http://127.0.0.1:5000/add -H "Content-Type: application/json" -d \'{"user":"Alice"}\'\n```\n\n#### Create IOU\n\n```sh\ncurl -X POST http://127.0.0.1:5000/iou -H "Content-Type: application/json" -d \'{"lender":"Alice","borrower":"Bob","amount":10.0}\'\n```\n\nThis should set up a basic RESTful API for tracking IOUs among four roommates. You can expand and refine the API further based on additional requirements.', refusal=None, role='assistant', annotations=None, audio=None, function_call=None, tool_calls=None, reasoning=None), stop_reason=None, token_ids=None, routed_experts=None)], created=1786135112, model='Qwen/Qwen2.5-Coder-7B-Instruct', object='chat.completion', moderation=None, service_tier=None, system_fingerprint='vllm-0.26.0-d384e2c5', usage=CompletionUsage(completion_tokens=818, prompt_tokens=1251, total_tokens=2069, completion_tokens_details=None, prompt_tokens_details=None), prompt_logprobs=None, prompt_token_ids=None, prompt_text=None, kv_transfer_params=None, ec_transfer_params=None, metrics=None)
