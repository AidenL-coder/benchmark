
========== User Instruction ==========
I have uploaded a code repository in the directory /testbed/. Help solve the following problem.

<problem_description>
# Instructions append

## Exception messages

Sometimes it is necessary to [raise an exception](https://docs.python.org/3/tutorial/errors.html#raising-exceptions). When you do this, you should always include a **meaningful error message** to indicate what the source of the error is. This makes your code more readable and helps significantly with debugging. For situations where you know that the error source will be a certain type, you can choose to raise one of the [built in error types](https://docs.python.org/3/library/exceptions.html#base-classes), but should still include a meaningful message.

This particular exercise requires that you refactor how/where the [raise statement](https://docs.python.org/3/reference/simple_stmts.html#the-raise-statement) is used to "throw" a `ValueError` for invalid tree input. The tests will only pass if the code both `raise`s the appropriate `exception` and includes an appropriate message with it.


# Instructions

Refactor a tree building algorithm.

Some web-forums have a tree layout, so posts are presented as a tree.
However the posts are typically stored in a database as an unsorted set of records.
Thus when presenting the posts to the user the tree structure has to be reconstructed.

Your job will be to refactor a working but slow and ugly piece of code that implements the tree building logic for highly abstracted records.
The records only contain an ID number and a parent ID number.
The ID number is always between 0 (inclusive) and the length of the record list (exclusive).
All records have a parent ID lower than their own ID, except for the root record, which has a parent ID that's equal to its own ID.

An example tree:

```text
root (ID: 0, parent ID: 0)
|-- child1 (ID: 1, parent ID: 0)
|    |-- grandchild1 (ID: 2, parent ID: 1)
|    +-- grandchild2 (ID: 4, parent ID: 1)
+-- child2 (ID: 3, parent ID: 0)
|    +-- grandchild3 (ID: 6, parent ID: 3)
+-- child3 (ID: 5, parent ID: 0)
```



</problem_description>

Your task is to make changes to the files in the /testbed/ directory to address the <problem_description>. I have already taken care of the required dependencies.


Please analyze the problem description carefully. Then make edits to the code files to complete the instruction.
Tool Response: ChatCompletion(id='chatcmpl-b2f9ba0bd5e4a89c', choices=[Choice(finish_reason='stop', index=0, logprobs=None, message=ChatCompletionMessage(content='Let\'s start by analyzing the problem description and identifying the key requirements:\n\n1. **Tree Building Algorithm**: We need to build a tree from a list of records where each record contains an ID and a parent ID.\n2. **Exception Handling**: When encountering invalid input, we need to raise a `ValueError` with a meaningful message.\n3. **Refactoring**: The existing implementation is slow and ugly, so we need to refactor it for better performance and readability.\n\nGiven these points, let\'s proceed with the refactoring. We\'ll assume there is a file named `tree_builder.py` in the `/testbed/` directory that contains the current implementation of the tree-building algorithm.\n\n### Step-by-Step Refactoring\n\n1. **Identify the Current Implementation**: Open the `tree_builder.py` file and locate the function responsible for building the tree.\n2. **Validate Input**: Ensure that the input list is valid and that each record meets the criteria (ID and parent ID constraints).\n3. **Raise Exceptions**: Raise a `ValueError` with a meaningful message if the input is invalid.\n4. **Optimize the Algorithm**: Improve the efficiency of the tree-building algorithm.\n\n### Example Code Refactoring\n\nAssuming the current implementation looks something like this:\n\n```python\ndef build_tree(records):\n    tree = {}\n    for record in records:\n        node_id = record[\'id\']\n        parent_id = record[\'parent_id\']\n        if parent_id == node_id:\n            tree[node_id] = []\n        else:\n            if parent_id not in tree:\n                tree[parent_id] = []\n            tree[parent_id].append(node_id)\n    return tree\n```\n\nWe can refactor it as follows:\n\n```python\ndef build_tree(records):\n    # Validate input\n    if not isinstance(records, list):\n        raise ValueError("Input must be a list of records.")\n    \n    if not all(isinstance(record, dict) for record in records):\n        raise ValueError("Each record must be a dictionary.")\n    \n    if not all(\'id\' in record and \'parent_id\' in record for record in records):\n        raise ValueError("Each record must contain \'id\' and \'parent_id\'.")\n    \n    if any(not isinstance(record[\'id\'], int) or not isinstance(record[\'parent_id\'], int) for record in records):\n        raise ValueError("Both \'id\' and \'parent_id\' must be integers.")\n    \n    if any(record[\'id\'] < 0 or record[\'id\'] >= len(records) for record in records):\n        raise ValueError("Invalid \'id\' value. Must be between 0 and the length of the records list (exclusive).")\n    \n    if any(record[\'parent_id\'] < 0 or record[\'parent_id\'] != record[\'id\'] and record[\'parent_id\'] >= len(records) for record in records):\n        raise ValueError("Invalid \'parent_id\' value. Must be less than the \'id\' or equal to the \'id\' for the root node.")\n    \n    # Build the tree\n    tree = {}\n    for record in records:\n        node_id = record[\'id\']\n        parent_id = record[\'parent_id\']\n        if parent_id == node_id:\n            if node_id in tree:\n                raise ValueError(f"Duplicate root node found with ID {node_id}.")\n            tree[node_id] = []\n        else:\n            if parent_id not in tree:\n                raise ValueError(f"Parent node with ID {parent_id} not found for node with ID {node_id}.")\n            tree[parent_id].append(node_id)\n    \n    return tree\n```\n\n### Explanation\n\n1. **Validation**:\n   - Check if the input is a list.\n   - Ensure each record is a dictionary.\n   - Verify that each record contains `\'id\'` and `\'parent_id\'`.\n   - Ensure that both `\'id\'` and `\'parent_id\'` are integers.\n   - Validate that `\'id\'` values are within the valid range.\n   - Validate that `\'parent_id\'` values are within the valid range and match the rules for the root node.\n\n2. **Tree Construction**:\n   - Initialize an empty dictionary `tree`.\n   - Iterate through each record and build the tree structure.\n   - Handle cases where the parent node does not exist or duplicate root nodes are found.\n\nBy following these steps, we ensure that the tree-building algorithm is robust, efficient, and raises meaningful exceptions for invalid input.', refusal=None, role='assistant', annotations=None, audio=None, function_call=None, tool_calls=None, reasoning=None), stop_reason=None, token_ids=None, routed_experts=None)], created=1786131129, model='Qwen/Qwen2.5-Coder-7B-Instruct', object='chat.completion', moderation=None, service_tier=None, system_fingerprint='vllm-0.26.0-d384e2c5', usage=CompletionUsage(completion_tokens=904, prompt_tokens=1205, total_tokens=2109, completion_tokens_details=None, prompt_tokens_details=None), prompt_logprobs=None, prompt_token_ids=None, prompt_text=None, kv_transfer_params=None, ec_transfer_params=None, metrics=None)
