
========== User Instruction ==========
I have uploaded a code repository in the directory /testbed/. Help solve the following problem.

<problem_description>
# Instructions

Score a bowling game.

Bowling is a game where players roll a heavy ball to knock down pins arranged in a triangle.
Write code to keep track of the score of a game of bowling.

## Scoring Bowling

The game consists of 10 frames.
A frame is composed of one or two ball throws with 10 pins standing at frame initialization.
There are three cases for the tabulation of a frame.

- An open frame is where a score of less than 10 is recorded for the frame.
  In this case the score for the frame is the number of pins knocked down.

- A spare is where all ten pins are knocked down by the second throw.
  The total value of a spare is 10 plus the number of pins knocked down in their next throw.

- A strike is where all ten pins are knocked down by the first throw.
  The total value of a strike is 10 plus the number of pins knocked down in the next two throws.
  If a strike is immediately followed by a second strike, then the value of the first strike cannot be determined until the ball is thrown one more time.

Here is a three frame example:

|  Frame 1   |  Frame 2   |     Frame 3      |
| :--------: | :--------: | :--------------: |
| X (strike) | 5/ (spare) | 9 0 (open frame) |

Frame 1 is (10 + 5 + 5) = 20

Frame 2 is (5 + 5 + 9) = 19

Frame 3 is (9 + 0) = 9

This means the current running total is 48.

The tenth frame in the game is a special case.
If someone throws a spare or a strike then they get one or two fill balls respectively.
Fill balls exist to calculate the total of the 10th frame.
Scoring a strike or spare on the fill ball does not give the player more fill balls.
The total value of the 10th frame is the total number of pins knocked down.

For a tenth frame of X1/ (strike and a spare), the total value is 20.

For a tenth frame of XXX (three strikes), the total value is 30.

## Requirements

Write code to keep track of the score of a game of bowling.
It should support two operations:

- `roll(pins : int)` is called each time the player rolls a ball.
  The argument is the number of pins knocked down.
- `score() : int` is called only at the very end of the game.
  It returns the total score for that game.



</problem_description>

Your task is to make changes to the files in the /testbed/ directory to address the <problem_description>. I have already taken care of the required dependencies.


Please analyze the problem description carefully. Then make edits to the code files to complete the instruction.
Tool Response: ChatCompletion(id='chatcmpl-917f1b4b413997ac', choices=[Choice(finish_reason='stop', index=0, logprobs=None, message=ChatCompletionMessage(content='Let\'s approach this step-by-step. We\'ll create a Python script to handle the scoring of a bowling game. We\'ll define two classes: `Game` and `Frame`. The `Game` class will manage the sequence of rolls and calculate the final score, while the `Frame` class will handle the scoring logic for individual frames.\n\nFirst, let\'s create the necessary files and structure.\n\n### Step 1: Create the `bowling_game.py` File\n\n```python\nclass Frame:\n    def __init__(self):\n        self.rolls = []\n    \n    def roll(self, pins):\n        self.rolls.append(pins)\n    \n    def score(self):\n        if len(self.rolls) == 2:\n            return sum(self.rolls)\n        elif len(self.rolls) == 1:\n            return self.rolls[0]\n        else:\n            raise ValueError("Invalid number of rolls in frame")\n\nclass Game:\n    def __init__(self):\n        self.frames = [Frame() for _ in range(10)]\n        self.current_frame = 0\n        self.current_roll_in_frame = 0\n    \n    def roll(self, pins):\n        if self.current_frame >= 10:\n            raise ValueError("All frames have been rolled")\n        \n        self.frames[self.current_frame].roll(pins)\n        \n        if pins == 10:  # Strike\n            if self.current_frame < 9:\n                self.current_frame += 1\n                self.current_roll_in_frame = 0\n        elif self.current_roll_in_frame == 0:\n            self.current_roll_in_frame += 1\n        else:\n            self.current_roll_in_frame = 0\n            self.current_frame += 1\n    \n    def score(self):\n        total_score = 0\n        \n        for i in range(10):\n            frame = self.frames[i]\n            if len(frame.rolls) == 2:\n                total_score += sum(frame.rolls)\n            elif len(frame.rolls) == 1:\n                total_score += frame.rolls[0]\n            \n            if i < 9:\n                next_frame = self.frames[i + 1]\n                if len(next_frame.rolls) == 2:\n                    total_score += sum(next_frame.rolls)\n                elif len(next_frame.rolls) == 1:\n                    total_score += next_frame.rolls[0]\n                \n                if len(frame.rolls) == 1 and frame.rolls[0] == 10:  # Strike\n                    total_score += sum(next_frame.rolls)\n                elif len(frame.rolls) == 2 and sum(frame.rolls) == 10:  # Spare\n                    total_score += next_frame.rolls[0]\n        \n        return total_score\n```\n\n### Step 2: Create the `main.py` File\n\nThis file will demonstrate how to use the `Game` and `Frame` classes.\n\n```python\nfrom bowling_game import Game\n\ndef main():\n    game = Game()\n    \n    # Example rolls\n    game.roll(10)  # Strike\n    game.roll(5)\n    game.roll(5)\n    \n    game.roll(7)\n    game.roll(2)\n    \n    game.roll(6)\n    game.roll(4)\n    \n    game.roll(10)  # Strike\n    game.roll(5)\n    game.roll(3)\n    \n    game.roll(10)  # Strike\n    game.roll(10)  # Strike\n    game.roll(10)  # Strike\n    \n    print("Final Score:", game.score())\n\nif __name__ == "__main__":\n    main()\n```\n\n### Step 3: Update the Directory Structure\n\nEnsure your directory structure looks like this:\n\n```\n/testbed/\n    bowling_game.py\n    main.py\n```\n\n### Step 4: Run the Script\n\nNavigate to the `/testbed/` directory and run the `main.py` script using Python:\n\n```sh\npython main.py\n```\n\nThis should output the final score based on the example rolls provided.\n\n### Explanation\n\n- **Frame Class**: Manages the rolls within a single frame. It can handle both strikes and spares.\n- **Game Class**: Manages multiple frames and calculates the total score. It handles the transition between frames and accounts for strikes and spares.\n\nBy following these steps, you should be able to implement a basic bowling game scorer in Python.', refusal=None, role='assistant', annotations=None, audio=None, function_call=None, tool_calls=None, reasoning=None), stop_reason=None, token_ids=None, routed_experts=None)], created=1786137588, model='Qwen/Qwen2.5-Coder-7B-Instruct', object='chat.completion', moderation=None, service_tier=None, system_fingerprint='vllm-0.26.0-d384e2c5', usage=CompletionUsage(completion_tokens=906, prompt_tokens=1290, total_tokens=2196, completion_tokens_details=None, prompt_tokens_details=None), prompt_logprobs=None, prompt_token_ids=None, prompt_text=None, kv_transfer_params=None, ec_transfer_params=None, metrics=None)
