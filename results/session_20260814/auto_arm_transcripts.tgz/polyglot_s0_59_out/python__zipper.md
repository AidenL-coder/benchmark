
========== User Instruction ==========
I have uploaded a code repository in the directory /testbed/. Help solve the following problem.

<problem_description>
# Instructions

Creating a zipper for a binary tree.

[Zippers][zipper] are a purely functional way of navigating within a data structure and manipulating it.
They essentially contain a data structure and a pointer into that data structure (called the focus).

For example given a rose tree (where each node contains a value and a list of child nodes) a zipper might support these operations:

- `from_tree` (get a zipper out of a rose tree, the focus is on the root node)
- `to_tree` (get the rose tree out of the zipper)
- `value` (get the value of the focus node)
- `prev` (move the focus to the previous child of the same parent,
  returns a new zipper)
- `next` (move the focus to the next child of the same parent, returns a
  new zipper)
- `up` (move the focus to the parent, returns a new zipper)
- `set_value` (set the value of the focus node, returns a new zipper)
- `insert_before` (insert a new subtree before the focus node, it
  becomes the `prev` of the focus node, returns a new zipper)
- `insert_after` (insert a new subtree after the focus node, it becomes
  the `next` of the focus node, returns a new zipper)
- `delete` (removes the focus node and all subtrees, focus moves to the
  `next` node if possible otherwise to the `prev` node if possible,
  otherwise to the parent node, returns a new zipper)

[zipper]: https://en.wikipedia.org/wiki/Zipper_%28data_structure%29



</problem_description>

Your task is to make changes to the files in the /testbed/ directory to address the <problem_description>. I have already taken care of the required dependencies.


Please analyze the problem description carefully. Then make edits to the code files to complete the instruction.
Tool Response: ChatCompletion(id='chatcmpl-909fbb922bcf1429', choices=[Choice(finish_reason='stop', index=0, logprobs=None, message=ChatCompletionMessage(content='Let\'s start by creating a basic implementation of a zipper for a binary tree. We\'ll create the necessary functions and ensure they work together correctly.\n\nFirst, let\'s define the structure of our binary tree node and the zipper. We\'ll then implement the required operations.\n\n### Step 1: Define the Binary Tree Node Structure\n\nCreate a file named `binary_tree.py` in the `/testbed/` directory.\n\n```python\nclass TreeNode:\n    def __init__(self, value=0, left=None, right=None):\n        self.value = value\n        self.left = left\n        self.right = right\n```\n\n### Step 2: Implement the Zipper Operations\n\nCreate another file named `zipper.py` in the `/testbed/` directory.\n\n```python\nclass Zipper:\n    class Focus:\n        def __init__(self, tree, parent=None, prev=None, next_node=None):\n            self.tree = tree\n            self.parent = parent\n            self.prev = prev\n            self.next_node = next_node\n\n    def __init__(self, tree):\n        self.focus = self.Focus(tree)\n\n    @classmethod\n    def from_tree(cls, tree):\n        return cls(tree)\n\n    def to_tree(self):\n        return self.focus.tree\n\n    def value(self):\n        return self.focus.tree.value\n\n    def prev(self):\n        if self.focus.prev:\n            new_focus = self.Focus(\n                self.focus.prev,\n                self.focus.tree,\n                self.focus.prev.left,\n                self.focus.prev.right\n            )\n            return Zipper(new_focus)\n        return None\n\n    def next(self):\n        if self.focus.next_node:\n            new_focus = self.Focus(\n                self.focus.next_node,\n                self.focus.tree,\n                self.focus.next_node.left,\n                self.focus.next_node.right\n            )\n            return Zipper(new_focus)\n        return None\n\n    def up(self):\n        if self.focus.parent:\n            new_focus = self.Focus(\n                self.focus.parent,\n                self.focus.parent.parent,\n                self.focus.parent.left,\n                self.focus.parent.right\n            )\n            return Zipper(new_focus)\n        return None\n\n    def set_value(self, value):\n        new_tree = TreeNode(value, self.focus.tree.left, self.focus.tree.right)\n        new_focus = self.Focus(\n            new_tree,\n            self.focus.parent,\n            self.focus.prev,\n            self.focus.next_node\n        )\n        return Zipper(new_focus)\n\n    def insert_before(self, subtree):\n        new_left = subtree\n        new_right = TreeNode(self.focus.tree.value, self.focus.tree.left, self.focus.tree.right)\n        new_tree = TreeNode(0, new_left, new_right)\n        new_focus = self.Focus(\n            new_tree,\n            self.focus.parent,\n            self.focus.prev,\n            self.focus.next_node\n        )\n        return Zipper(new_focus)\n\n    def insert_after(self, subtree):\n        new_left = TreeNode(self.focus.tree.value, self.focus.tree.left, self.focus.tree.right)\n        new_right = subtree\n        new_tree = TreeNode(0, new_left, new_right)\n        new_focus = self.Focus(\n            new_tree,\n            self.focus.parent,\n            self.focus.prev,\n            self.focus.next_node\n        )\n        return Zipper(new_focus)\n\n    def delete(self):\n        if self.focus.prev:\n            new_focus = self.Focus(\n                self.focus.prev,\n                self.focus.parent,\n                self.focus.prev.left,\n                self.focus.prev.right\n            )\n        elif self.focus.next_node:\n            new_focus = self.Focus(\n                self.focus.next_node,\n                self.focus.parent,\n                self.focus.next_node.left,\n                self.focus.next_node.right\n            )\n        else:\n            new_focus = self.Focus(\n                self.focus.parent,\n                self.focus.parent.parent,\n                self.focus.parent.left,\n                self.focus.parent.right\n            )\n        return Zipper(new_focus)\n```\n\n### Step 3: Test the Implementation\n\nWe can now test the implementation by creating a simple binary tree and using the zipper operations.\n\nCreate a file named `test_zipper.py` in the `/testbed/` directory.\n\n```python\nfrom binary_tree import TreeNode\nfrom zipper import Zipper\n\n# Create a simple binary tree\nroot = TreeNode(1)\nleft_child = TreeNode(2)\nright_child = TreeNode(3)\nroot.left = left_child\nroot.right = right_child\n\n# Create a zipper from the tree\nzipper = Zipper.from_tree(root)\n\n# Get the value at the focus\nprint("Value at focus:", zipper.value())\n\n# Move to the left child\nnew_zipper = zipper.prev()\nprint("Value at new focus:", new_zipper.value())\n\n# Set a new value at the focus\nnew_zipper = new_zipper.set_value(4)\nprint("New value at focus:", new_zipper.value())\n\n# Delete the current focus\nnew_zipper = new_zipper.delete()\nprint("Focus after deletion:", new_zipper.to_tree().value)\n```\n\n### Step 4: Run the Tests\n\nTo run the tests, you can use the following command:\n\n```bash\npython test_zipper.py\n```\n\nThis should output the values at different stages of the zipper operations.\n\n### Conclusion\n\nWe have implemented a basic zipper for a binary tree. This implementation includes the required operations such as `from_tree`, `to_tree`, `value`, `prev`, `next`, `up`, `set_value`, `insert_before`, `insert_after`, and `delete`. You can further extend and refine this implementation based on your specific requirements.', refusal=None, role='assistant', annotations=None, audio=None, function_call=None, tool_calls=None, reasoning=None), stop_reason=None, token_ids=None, routed_experts=None)], created=1786134792, model='Qwen/Qwen2.5-Coder-7B-Instruct', object='chat.completion', moderation=None, service_tier=None, system_fingerprint='vllm-0.26.0-d384e2c5', usage=CompletionUsage(completion_tokens=1131, prompt_tokens=1077, total_tokens=2208, completion_tokens_details=None, prompt_tokens_details=None), prompt_logprobs=None, prompt_token_ids=None, prompt_text=None, kv_transfer_params=None, ec_transfer_params=None, metrics=None)
