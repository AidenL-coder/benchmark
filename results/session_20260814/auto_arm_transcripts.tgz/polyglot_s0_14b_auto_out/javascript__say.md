
========== User Instruction ==========
I have uploaded a code repository in the directory /testbed/. Help solve the following problem.

<problem_description>
# Instructions

Given a number from 0 to 999,999,999,999, spell out that number in English.

## Step 1

Handle the basic case of 0 through 99.

If the input to the program is `22`, then the output should be `'twenty-two'`.

Your program should complain loudly if given a number outside the blessed range.

Some good test cases for this program are:

- 0
- 14
- 50
- 98
- -1
- 100

### Extension

If you're on a Mac, shell out to Mac OS X's `say` program to talk out loud.
If you're on Linux or Windows, eSpeakNG may be available with the command `espeak`.

## Step 2

Implement breaking a number up into chunks of thousands.

So `1234567890` should yield a list like 1, 234, 567, and 890, while the far simpler `1000` should yield just 1 and 0.

## Step 3

Now handle inserting the appropriate scale word between those chunks.

So `1234567890` should yield `'1 billion 234 million 567 thousand 890'`

The program must also report any values that are out of range.
It's fine to stop at "trillion".

## Step 4

Put it all together to get nothing but plain English.

`12345` should give `twelve thousand three hundred forty-five`.

The program must also report any values that are out of range.



</problem_description>

Your task is to make changes to the files in the /testbed/ directory to address the <problem_description>. I have already taken care of the required dependencies.


Please analyze the problem description carefully. Then make edits to the code files to complete the instruction.
Tool Response: ChatCompletion(id='chatcmpl-b92065b3f68953b6', choices=[Choice(finish_reason='stop', index=0, logprobs=None, message=ChatCompletionMessage(content='To address the problem described, we need to implement a Python script that can convert a number from 0 to 999,999,999,999 into its English representation. We\'ll break down the solution into several steps and make the necessary changes to the code files in the `/testbed/` directory.\n\n### Step 1: Handle the basic case of 0 through 99\n\nWe\'ll create a function to convert numbers from 0 to 99 into words. We\'ll also add error handling for numbers outside the range.\n\n### Step 2: Break a number up into chunks of thousands\n\nWe\'ll create a function to split a number into chunks of thousands.\n\n### Step 3: Insert the appropriate scale word between those chunks\n\nWe\'ll create a function to convert these chunks into their respective scale words (e.g., "thousand", "million", "billion").\n\n### Step 4: Put it all together to get nothing but plain English\n\nWe\'ll combine all the functions to convert the entire number into its English representation.\n\nLet\'s start by implementing these steps in a Python script.\n\n```python\n# /testbed/spell_number.py\n\ndef number_to_words(n):\n    if n < 0 or n > 999_999_999_999:\n        raise ValueError("Number out of range. Please enter a number between 0 and 999,999,999,999.")\n\n    # Basic case: 0 through 99\n    def below_100(num):\n        units = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"]\n        teens = ["ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"]\n        tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]\n\n        if num < 10:\n            return units[num]\n        elif 10 <= num < 20:\n            return teens[num - 10]\n        else:\n            ten, unit = divmod(num, 10)\n            return tens[ten] + (\'-\' + units[unit] if unit != 0 else \'\')\n\n    # Break a number up into chunks of thousands\n    def chunkify(num):\n        chunks = []\n        while num > 0:\n            chunks.append(num % 1000)\n            num //= 1000\n        return chunks[::-1]\n\n    # Insert the appropriate scale word between those chunks\n    def scale_word(chunk_index):\n        scales = ["", "thousand", "million", "billion", "trillion"]\n        return scales[chunk_index] if chunk_index < len(scales) else ""\n\n    # Convert the entire number into its English representation\n    def convert_to_words(num):\n        if num == 0:\n            return "zero"\n\n        words = []\n        chunks = chunkify(num)\n        for i, chunk in enumerate(chunks):\n            if chunk != 0:\n                words.append(below_100(chunk) + \' \' + scale_word(i))\n\n        return \' \'.join(words).strip()\n\n    return convert_to_words(n)\n\n# Example usage\nif __name__ == "__main__":\n    try:\n        number = int(input("Enter a number: "))\n        print(number_to_words(number))\n    except ValueError as e:\n        print(e)\n```\n\n### Explanation:\n\n1. **number_to_words**: This is the main function that converts a number to words.\n2. **below_100**: Handles numbers from 0 to 99.\n3. **chunkify**: Splits the number into chunks of thousands.\n4. **scale_word**: Provides the appropriate scale word for each chunk.\n5. **convert_to_words**: Combines all the chunks into their English representation.\n\n### Testing:\n\nYou can test the script by running it and entering different numbers. For example:\n\n```bash\npython /testbed/spell_number.py\n```\n\nEnter numbers like `22`, `1234567890`, and observe the output.\n\nThis script should cover all the steps outlined in the problem description. If you need further modifications or additional features, please let me know!', refusal=None, role='assistant', annotations=None, audio=None, function_call=None, tool_calls=None, reasoning=None), stop_reason=None, token_ids=None, routed_experts=None)], created=1786422402, model='Qwen/Qwen2.5-Coder-14B-Instruct-AWQ', object='chat.completion', moderation=None, service_tier=None, system_fingerprint='vllm-0.26.0-26d94dd6', usage=CompletionUsage(completion_tokens=936, prompt_tokens=1091, total_tokens=2027, completion_tokens_details=None, prompt_tokens_details=None), prompt_logprobs=None, prompt_token_ids=None, prompt_text=None, kv_transfer_params=None, ec_transfer_params=None, metrics=None)
