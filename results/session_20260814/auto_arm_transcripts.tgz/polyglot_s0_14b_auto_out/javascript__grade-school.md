
========== User Instruction ==========
I have uploaded a code repository in the directory /testbed/. Help solve the following problem.

<problem_description>
# Instructions

Given students' names along with the grade that they are in, create a roster for the school.

In the end, you should be able to:

- Add a student's name to the roster for a grade
  - "Add Jim to grade 2."
  - "OK."
- Get a list of all students enrolled in a grade
  - "Which students are in grade 2?"
  - "We've only got Jim just now."
- Get a sorted list of all students in all grades.
  Grades should sort as 1, 2, 3, etc., and students within a grade should be sorted alphabetically by name.
  - "Who all is enrolled in school right now?"
  - "Let me think.
    We have Anna, Barb, and Charlie in grade 1, Alex, Peter, and Zoe in grade 2 and Jim in grade 5.
    So the answer is: Anna, Barb, Charlie, Alex, Peter, Zoe and Jim"

Note that all our students only have one name (It's a small town, what do you want?) and each student cannot be added more than once to a grade or the roster.
In fact, when a test attempts to add the same student more than once, your implementation should indicate that this is incorrect.



</problem_description>

Your task is to make changes to the files in the /testbed/ directory to address the <problem_description>. I have already taken care of the required dependencies.


Please analyze the problem description carefully. Then make edits to the code files to complete the instruction.
Tool Response: ChatCompletion(id='chatcmpl-a0c48bb915bbb3ca', choices=[Choice(finish_reason='stop', index=0, logprobs=None, message=ChatCompletionMessage(content='To solve the problem described, we need to implement a system that can manage student rosters by grade. We\'ll use a Python script to handle the operations: adding students, listing students by grade, and providing a sorted list of all students.\n\nHere are the steps we\'ll follow:\n\n1. **Create a data structure** to store the students by grade.\n2. **Implement functions** to add a student to a grade, list students by grade, and get a sorted list of all students.\n3. **Update the main script** to handle user input and call these functions accordingly.\n\nLet\'s start by analyzing the existing files in the `/testbed/` directory. We\'ll assume there is a main script named `roster.py` and any other necessary files.\n\n### Step 1: Create a Data Structure\n\nWe\'ll use a dictionary where the keys are grades (integers) and the values are sets of student names. Using sets ensures that each student is unique within a grade.\n\n### Step 2: Implement Functions\n\nWe\'ll implement three functions:\n- `add_student(name, grade)`: Adds a student to the specified grade.\n- `list_students_by_grade(grade)`: Returns a list of students in the specified grade.\n- `get_sorted_list_of_all_students()`: Returns a sorted list of all students across all grades.\n\n### Step 3: Update the Main Script\n\nWe\'ll update the main script to handle user input and call the appropriate functions based on the input.\n\nHere\'s how the code will look:\n\n#### `roster.py`\n\n```python\nimport sys\n\n# Data structure to store students by grade\nstudents_by_grade = {}\n\ndef add_student(name, grade):\n    if grade not in students_by_grade:\n        students_by_grade[grade] = set()\n    if name in students_by_grade[grade]:\n        print(f"Student {name} is already in grade {grade}.")\n    else:\n        students_by_grade[grade].add(name)\n        print("OK.")\n\ndef list_students_by_grade(grade):\n    if grade not in students_by_grade:\n        print(f"No students in grade {grade}.")\n    else:\n        students = sorted(students_by_grade[grade])\n        print(", ".join(students))\n\ndef get_sorted_list_of_all_students():\n    all_students = []\n    for grade in sorted(students_by_grade.keys()):\n        all_students.extend(sorted(students_by_grade[grade]))\n    print(", ".join(all_students))\n\ndef main():\n    while True:\n        command = input().strip()\n        if command.startswith("Add "):\n            parts = command.split()\n            if len(parts) != 4:\n                print("Invalid command.")\n                continue\n            name = parts[1]\n            try:\n                grade = int(parts[3])\n            except ValueError:\n                print("Invalid grade.")\n                continue\n            add_student(name, grade)\n        elif command.startswith("Which students are in grade "):\n            parts = command.split()\n            if len(parts) != 6:\n                print("Invalid command.")\n                continue\n            try:\n                grade = int(parts[-1])\n            except ValueError:\n                print("Invalid grade.")\n                continue\n            list_students_by_grade(grade)\n        elif command == "Who all is enrolled in school right now?":\n            get_sorted_list_of_all_students()\n        elif command == "exit":\n            break\n        else:\n            print("Invalid command.")\n\nif __name__ == "__main__":\n    main()\n```\n\n### Explanation\n\n- **Data Structure**: We use a dictionary `students_by_grade` where keys are grades and values are sets of student names.\n- **Functions**:\n  - `add_student(name, grade)`: Adds a student to the specified grade. If the student is already in the grade, it prints an error message.\n  - `list_students_by_grade(grade)`: Lists all students in the specified grade. If no students are in the grade, it prints a message indicating that.\n  - `get_sorted_list_of_all_students()`: Provides a sorted list of all students across all grades.\n- **Main Loop**: Handles user input and calls the appropriate functions based on the input.\n\nThis script should be placed in the `/testbed/` directory and executed. It will handle the operations as described in the problem statement.', refusal=None, role='assistant', annotations=None, audio=None, function_call=None, tool_calls=None, reasoning=None), stop_reason=None, token_ids=None, routed_experts=None)], created=1786422758, model='Qwen/Qwen2.5-Coder-14B-Instruct-AWQ', object='chat.completion', moderation=None, service_tier=None, system_fingerprint='vllm-0.26.0-26d94dd6', usage=CompletionUsage(completion_tokens=877, prompt_tokens=997, total_tokens=1874, completion_tokens_details=None, prompt_tokens_details=None), prompt_logprobs=None, prompt_token_ids=None, prompt_text=None, kv_transfer_params=None, ec_transfer_params=None, metrics=None)
