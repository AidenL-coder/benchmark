
========== User Instruction ==========
I have uploaded a code repository in the directory /testbed/. Help solve the following problem.

<problem_description>
# Instructions

Your task is to generate the perfect mazes for Mickey and Minerva — those with only one solution and no isolated sections.
Here's what you need to know:

- The maze has a rectangular shape with an opening at the start and end.
- The maze has rooms and passages, which intersect at right angles.
- The program should accept two parameters: rows and columns. The maze should be between 5 and 100 cells in size.
- A maze which is `x` columns wide and `y` rows high should be `2x + 1` characters wide and `2y + 1` characters high.
- If no seed is provided, generate a random maze. If the same seed is provided multiple times, the resulting maze should be the same each time.
- Use [box-drawing][Box-drawing] characters to draw walls, and an arrow symbol (⇨) for the entrance on the left and exit on the right.

It's time to create some perfect mazes for these adventurous mice!

## Examples

1. A small square maze 5x5 cells (or 11x11 characters)

    ```text
    ┌───────┬─┐
    │       │ │
    │ ┌─┬── │ │
    │ │ │   │ ⇨
    │ │ │ ──┤ │
    ⇨ │ │   │ │
    ┌─┤ └── │ │
    │ │     │ │
    │ │ ────┘ │
    │         │
    └─────────┘
    ```

2. A rectangular maze 6x18 cells

    ```text
    ┌───────────┬─────────┬───────────┬─┐
    │           │         │           │ │
    │ ┌───────┐ │ ┌─┐ ──┐ └───┐ ┌───┐ │ │
    │ │       │ │ │ │   │     │ │   │   ⇨
    │ └─┐ ┌─┐ │ │ │ ├── ├───┐ │ │ ──┼── │
    │   │ │ │   │   │   │   │ │ │   │   │
    └── │ │ ├───┴───┤ ┌─┘ ┌─┘ │ ├── │ ──┤
    ⇨   │   │       │ │   │   │ │   │   │
    ┌─┬─┴─┐ └─┐ ┌─┐ │ └─┐ │ ┌─┘ │ ──┴─┐ │
    │ │   │   │ │ │ │   │   │   │     │ │
    │ │ │ └── │ │ │ └── │ ──┘ ┌─┘ ──┐ │ │
    │   │       │       │     │     │   │
    └───┴───────┴───────┴─────┴─────┴───┘
    ```

[Box-drawing]: https://en.wikipedia.org/wiki/Box-drawing_character


# Introduction

Meet Mickey and Minerva, two clever mice who love to navigate their way through a maze to find cheese. They enjoy a good challenge, but with only their tiny mouse brains, they prefer if there is only one correct path to the cheese.


# Hints

## General

- You can use the [Random class][random-class] to generate random numbers.
- Read more in article: [Random Number Generators in Java 17][random-number-generators].

## Maze generation

You can use any algorithm to generate a perfect maze. The [recursive backtracker][recursive-backtracker] is a good choice.

## Box drawing characters

| Character | Name                                  | Unicode |
|:---------:|:--------------------------------------|:--------|
|     ┌     | box drawings light down and right     |  U+250C |
|     ─     | box drawings light horizontal         |  U+2500 |
|     ┬     | box drawings light down and horizontal|  U+252C |
|     ┐     | box drawings light down and left      |  U+2510 |
|     │     | box drawings light vertical           |  U+2502 |
|     └     | box drawings light up and right       |  U+2514 |
|     ┴     | box drawings light up and horizontal  |  U+2534 |
|     ┘     | box drawings light up and left        |  U+2518 |
|     ├     | box drawings light vertical and right |  U+2520 |
|     ⇨     | rightwards white arrow                |  U+21E8 |

[recursive-backtracker]: https://en.wikipedia.org/wiki/Maze_generation_algorithm
[random-class]: https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/Random.html
[random-number-generators]: https://www.baeldung.com/java-17-random-number-generators



</problem_description>

Your task is to make changes to the files in the /testbed/ directory to address the <problem_description>. I have already taken care of the required dependencies.


Please analyze the problem description carefully. Then make edits to the code files to complete the instruction.
Tool Response: ChatCompletion(id='chatcmpl-aadec406fec3804f', choices=[Choice(finish_reason='stop', index=0, logprobs=None, message=ChatCompletionMessage(content='To solve the problem of generating perfect mazes for Mickey and Minerva, we need to implement a maze generation algorithm in Java. The recursive backtracker algorithm is a good choice for this task. We will also need to handle the input parameters for the number of rows and columns, and optionally a seed for reproducibility.\n\nHere are the steps we will follow:\n\n1. **Read the existing codebase**: We will view the existing files in the `/testbed/` directory to understand the current structure and requirements.\n2. **Implement the maze generation algorithm**: We will write the Java code to generate a perfect maze using the recursive backtracker algorithm.\n3. **Handle input parameters**: We will modify the main method to accept the number of rows and columns as input parameters, and optionally a seed.\n4. **Draw the maze using box-drawing characters**: We will ensure that the maze is drawn using the specified box-drawing characters and includes the entrance and exit arrows.\n\nLet\'s start by viewing the existing files in the `/testbed/` directory.\n\n```json\n{\n  "name": "editor",\n  "arguments": {\n    "command": "view",\n    "path": "/testbed/"\n  }\n}\n```\n\nAfter viewing the files, we will proceed to implement the maze generation algorithm and make the necessary changes.', refusal=None, role='assistant', annotations=None, audio=None, function_call=None, tool_calls=None, reasoning=None), stop_reason=None, token_ids=None, routed_experts=None)], created=1786424074, model='Qwen/Qwen2.5-Coder-14B-Instruct-AWQ', object='chat.completion', moderation=None, service_tier=None, system_fingerprint='vllm-0.26.0-26d94dd6', usage=CompletionUsage(completion_tokens=270, prompt_tokens=1825, total_tokens=2095, completion_tokens_details=None, prompt_tokens_details=None), prompt_logprobs=None, prompt_token_ids=None, prompt_text=None, kv_transfer_params=None, ec_transfer_params=None, metrics=None)
