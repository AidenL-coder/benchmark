
========== User Instruction ==========
I have uploaded a code repository in the directory /testbed/. Help solve the following problem.

<problem_description>
# Instructions

Refactor a Markdown parser.

The markdown exercise is a refactoring exercise.
There is code that parses a given string with [Markdown syntax][markdown] and returns the associated HTML for that string.
Even though this code is confusingly written and hard to follow, somehow it works and all the tests are passing!
Your challenge is to re-write this code to make it easier to read and maintain while still making sure that all the tests keep passing.

It would be helpful if you made notes of what you did in your refactoring in comments so reviewers can see that, but it isn't strictly necessary.
The most important thing is to make the code better!

[markdown]: https://guides.github.com/features/mastering-markdown/



</problem_description>

Your task is to make changes to the files in the /testbed/ directory to address the <problem_description>. I have already taken care of the required dependencies.


Please analyze the problem description carefully. Then make edits to the code files to complete the instruction.
Tool Response: ChatCompletion(id='chatcmpl-a88e41446d72598a', choices=[Choice(finish_reason='stop', index=0, logprobs=None, message=ChatCompletionMessage(content='To tackle the refactoring of the Markdown parser, I\'ll first need to view the existing code in the `/testbed/` directory. Let\'s start by listing the files in that directory to identify the relevant ones.\n\n```json\n{\n  "name": "editor",\n  "arguments": {\n    "command": "view",\n    "path": "/testbed/"\n  }\n}\n```', refusal=None, role='assistant', annotations=None, audio=None, function_call=None, tool_calls=None, reasoning=None), stop_reason=None, token_ids=None, routed_experts=None)], created=1786424780, model='Qwen/Qwen2.5-Coder-14B-Instruct-AWQ', object='chat.completion', moderation=None, service_tier=None, system_fingerprint='vllm-0.26.0-26d94dd6', usage=CompletionUsage(completion_tokens=80, prompt_tokens=878, total_tokens=958, completion_tokens_details=None, prompt_tokens_details=None), prompt_logprobs=None, prompt_token_ids=None, prompt_text=None, kv_transfer_params=None, ec_transfer_params=None, metrics=None)
