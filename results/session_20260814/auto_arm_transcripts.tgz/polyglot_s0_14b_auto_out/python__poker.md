
========== User Instruction ==========
I have uploaded a code repository in the directory /testbed/. Help solve the following problem.

<problem_description>
# Instructions

Pick the best hand(s) from a list of poker hands.

See [Wikipedia][poker-hands] for an overview of poker hands.

[poker-hands]: https://en.wikipedia.org/wiki/List_of_poker_hands



</problem_description>

Your task is to make changes to the files in the /testbed/ directory to address the <problem_description>. I have already taken care of the required dependencies.


Please analyze the problem description carefully. Then make edits to the code files to complete the instruction.
Tool Response: ChatCompletion(id='chatcmpl-a0398bcd26d2f16f', choices=[Choice(finish_reason='stop', index=0, logprobs=None, message=ChatCompletionMessage(content='To help you solve the problem of picking the best hand(s) from a list of poker hands, I\'ll need to analyze the existing code in the `/testbed/` directory. Let\'s start by viewing the relevant files.\n\nFirst, let\'s view the contents of the `/testbed/` directory to see what files are available:\n\n```json\n{\n  "name": "editor",\n  "arguments": {\n    "command": "view",\n    "path": "/testbed/"\n  }\n}\n```', refusal=None, role='assistant', annotations=None, audio=None, function_call=None, tool_calls=None, reasoning=None), stop_reason=None, token_ids=None, routed_experts=None)], created=1786422710, model='Qwen/Qwen2.5-Coder-14B-Instruct-AWQ', object='chat.completion', moderation=None, service_tier=None, system_fingerprint='vllm-0.26.0-26d94dd6', usage=CompletionUsage(completion_tokens=104, prompt_tokens=780, total_tokens=884, completion_tokens_details=None, prompt_tokens_details=None), prompt_logprobs=None, prompt_token_ids=None, prompt_text=None, kv_transfer_params=None, ec_transfer_params=None, metrics=None)
