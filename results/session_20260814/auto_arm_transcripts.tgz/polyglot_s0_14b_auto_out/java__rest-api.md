
========== User Instruction ==========
I have uploaded a code repository in the directory /testbed/. Help solve the following problem.

<problem_description>
# Instructions

Implement a RESTful API for tracking IOUs.

Four roommates have a habit of borrowing money from each other frequently, and have trouble remembering who owes whom, and how much.

Your task is to implement a simple [RESTful API][restful-wikipedia] that receives [IOU][iou]s as POST requests, and can deliver specified summary information via GET requests.

## API Specification

### User object

```json
{
  "name": "Adam",
  "owes": {
    "Bob": 12.0,
    "Chuck": 4.0,
    "Dan": 9.5
  },
  "owed_by": {
    "Bob": 6.5,
    "Dan": 2.75
  },
  "balance": "<(total owed by other users) - (total owed to other users)>"
}
```

### Methods

| Description              | HTTP Method | URL    | Payload Format                                                            | Response w/o Payload                   | Response w/ Payload                                                             |
| ------------------------ | ----------- | ------ | ------------------------------------------------------------------------- | -------------------------------------- | ------------------------------------------------------------------------------- |
| List of user information | GET         | /users | `{"users":["Adam","Bob"]}`                                                | `{"users":<List of all User objects>}` | `{"users":<List of User objects for <users> (sorted by name)}`                  |
| Create user              | POST        | /add   | `{"user":<name of new user (unique)>}`                                    | N/A                                    | `<User object for new user>`                                                    |
| Create IOU               | POST        | /iou   | `{"lender":<name of lender>,"borrower":<name of borrower>,"amount":5.25}` | N/A                                    | `{"users":<updated User objects for <lender> and <borrower> (sorted by name)>}` |

## Other Resources

- [REST API Tutorial][restfulapi]
- Example RESTful APIs
  - [GitHub][github-rest]
  - [Reddit][reddit-rest]

[restful-wikipedia]: https://en.wikipedia.org/wiki/Representational_state_transfer
[iou]: https://en.wikipedia.org/wiki/IOU
[github-rest]: https://developer.github.com/v3/
[reddit-rest]: https://web.archive.org/web/20231202231149/https://www.reddit.com/dev/api/
[restfulapi]: https://restfulapi.net/



</problem_description>

Your task is to make changes to the files in the /testbed/ directory to address the <problem_description>. I have already taken care of the required dependencies.


Please analyze the problem description carefully. Then make edits to the code files to complete the instruction.
Tool Response: ChatCompletion(id='chatcmpl-80ddad4c7b6ee785', choices=[Choice(finish_reason='stop', index=0, logprobs=None, message=ChatCompletionMessage(content='To solve the problem of implementing a RESTful API for tracking IOUs, we need to create the necessary endpoints and handle the logic for creating users, adding IOUs, and retrieving user information. Below are the steps and the corresponding code changes:\n\n1. **Create the necessary files and directories**:\n   - Ensure there is a directory structure like `/testbed/app/` and files like `app.py`, `users.json`, etc.\n\n2. **Implement the Flask application**:\n   - Set up a Flask app to handle the routes for `/users`, `/add`, and `/iou`.\n\n3. **Handle user data**:\n   - Use a JSON file (`users.json`) to store user data persistently.\n\n4. **Implement the API endpoints**:\n   - Implement the logic for listing users, adding new users, and creating IOUs.\n\nHere are the detailed steps and the corresponding code:\n\n### Step 1: Directory Structure\nEnsure the following directory structure:\n```\n/testbed/\n├── app/\n│   ├── app.py\n│   └── users.json\n└── run.sh\n```\n\n### Step 2: Flask Application (`app.py`)\nCreate or update `app.py` with the following content:\n\n```python\nfrom flask import Flask, request, jsonify\nimport json\nimport os\n\napp = Flask(__name__)\nUSERS_FILE = \'users.json\'\n\ndef load_users():\n    if os.path.exists(USERS_FILE):\n        with open(USERS_FILE, \'r\') as f:\n            return json.load(f)\n    return {}\n\ndef save_users(users):\n    with open(USERS_FILE, \'w\') as f:\n        json.dump(users, f, indent=4)\n\n@app.route(\'/users\', methods=[\'GET\'])\ndef list_users():\n    users = load_users()\n    requested_users = request.args.get(\'users\', \'\').split(\',\')\n    if requested_users == [\'\']:\n        response_users = sorted(users.values(), key=lambda x: x[\'name\'])\n    else:\n        response_users = sorted([users[name] for name in requested_users if name in users], key=lambda x: x[\'name\'])\n    return jsonify({"users": response_users})\n\n@app.route(\'/add\', methods=[\'POST\'])\ndef add_user():\n    data = request.get_json()\n    name = data.get(\'user\')\n    if not name:\n        return jsonify({"error": "Invalid payload"}), 400\n    users = load_users()\n    if name in users:\n        return jsonify({"error": "User already exists"}), 400\n    users[name] = {\n        "name": name,\n        "owes": {},\n        "owed_by": {},\n        "balance": 0.0\n    }\n    save_users(users)\n    return jsonify(users[name])\n\n@app.route(\'/iou\', methods=[\'POST\'])\ndef create_iou():\n    data = request.get_json()\n    lender = data.get(\'lender\')\n    borrower = data.get(\'borrower\')\n    amount = data.get(\'amount\', 0.0)\n    if not lender or not borrower or amount <= 0:\n        return jsonify({"error": "Invalid payload"}), 400\n    users = load_users()\n    if lender not in users or borrower not in users:\n        return jsonify({"error": "User not found"}), 400\n    # Update lender\'s balance and owed_by\n    if borrower in users[lender][\'owed_by\']:\n        users[lender][\'owed_by\'][borrower] += amount\n    else:\n        users[lender][\'owed_by\'][borrower] = amount\n    users[lender][\'balance\'] -= amount\n    # Update borrower\'s balance and owes\n    if lender in users[borrower][\'owes\']:\n        users[borrower][\'owes\'][lender] += amount\n    else:\n        users[borrower][\'owes\'][lender] = amount\n    users[borrower][\'balance\'] += amount\n    save_users(users)\n    updated_users = [users[lender], users[borrower]]\n    return jsonify({"users": sorted(updated_users, key=lambda x: x[\'name\'])})\n\nif __name__ == \'__main__\':\n    app.run(debug=True, host=\'0.0.0.0\', port=5000)\n```\n\n### Step 3: Run Script (`run.sh`)\nCreate or update `run.sh` with the following content:\n\n```bash\n#!/bin/bash\ncd /testbed/app\nflask run --host=0.0.0.0 --port=5000\n```\n\nMake the script executable:\n\n```bash\nchmod +x run.sh\n```\n\n### Step 4: Initialize Users File (`users.json`)\nEnsure `users.json` is present and empty initially:\n\n```json\n{}\n```\n\n### Step 5: Start the Application\nRun the application using the `run.sh` script:\n\n```bash\n./run.sh\n```\n\nThis setup will create a RESTful API that allows you to manage IOUs between users. You can test the API using tools like `curl` or Postman.', refusal=None, role='assistant', annotations=None, audio=None, function_call=None, tool_calls=None, reasoning=None), stop_reason=None, token_ids=None, routed_experts=None)], created=1786424334, model='Qwen/Qwen2.5-Coder-14B-Instruct-AWQ', object='chat.completion', moderation=None, service_tier=None, system_fingerprint='vllm-0.26.0-26d94dd6', usage=CompletionUsage(completion_tokens=1046, prompt_tokens=1251, total_tokens=2297, completion_tokens_details=None, prompt_tokens_details=None), prompt_logprobs=None, prompt_token_ids=None, prompt_text=None, kv_transfer_params=None, ec_transfer_params=None, metrics=None)
